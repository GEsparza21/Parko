<?php
        include("conexion.php");
        $id= $_GET['id'];
        $eliminar= "DELETE FROM `inquilinos` WHERE idInquilinos= '$id'";
        
        $resultadoEliminar= mysqli_query($conexion, $eliminar);

        if($resultadoEliminar){
            header("Location: usuarios.php");
        }else{
            echo"<script>alert('No se pudo eliminar este registro'); window.history.go(-1);</script>";
        }
