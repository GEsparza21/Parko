<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Datos</title>
    <link rel="shortcut icon" href="img/logo.jpg">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap-theme.css">
    <script src="Bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="Bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/estilosEmpleadosNuevo.css">
</head>
<body>
    
<center>
    <form action="ActualizarEmpleadosBD.php" method="POST">
        <h1>Actualizar datos de empleados</h1>
        <hr>

        <?php
        include("conexion.php");
        $idUsuarios = $_GET["id"];
        $sql = "SELECT `idUsuarios`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `telefono` FROM `empleados` WHERE idUsuarios='$idUsuarios'";
        $resultado = mysqli_query($conexion, $sql);
        ?>

        <hr>
        <?php
        while ($filas = mysqli_fetch_assoc($resultado)) {
            ?>
            <label for="">Id de empleado</label>
            <input type="text" value="<?php echo $filas['idUsuarios'] ?>" name="idUsuarios" disabled>

            <!-- Agrega el campo oculto con el idUsuarios -->
            <input type="hidden" value="<?php echo $filas['idUsuarios'] ?>" name="idUsuarios">

            <label for="">Nombre</label>
            <input type="text" value="<?php echo $filas['nombre'] ?>" name="nombre" disabled>

            <label for="">Apellido Paterno</label>
            <input type="text" value="<?php echo $filas['apellidoPaterno'] ?>" name="apellidoPaterno" disabled>

            <label for="">Apellido Materno</label>
            <input type="text" value="<?php echo $filas['apellidoMaterno'] ?>" name="apellidoMaterno" disabled>

            <label for="">Teléfono</label>
            <input type="tel" value="<?php echo $filas['telefono'] ?>" oninput="validarNumeros(event)" required minlength="10" maxlength="10" name="telefono">

            <label for="">Contraseña</label>
            <input type="password" nombre="password" placeholder="Actualizar contraseña" name="password" required minlength="8" maxlength="20">
            <hr>
        <?php } mysqli_free_result($resultado); ?>

        <center><button type="submit">Guardar</button></center>
    </form>
    
    <script>
        function validarNumeros(event) {
          const input = event.target;
          const inputValue = input.value;
        
          // Remover caracteres no numéricos del valor ingresado
          const soloNumeros = inputValue.replace(/\D/g, '');
        
          // Actualizar el valor del input con solo números
          input.value = soloNumeros;
        }
</script>
    
    
</center>
</body>
</html>