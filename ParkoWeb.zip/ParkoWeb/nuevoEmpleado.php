<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo empleado</title>
    <link rel="shortcut icon" href="img/logo.jpg">
<link rel="stylesheet" href="css/estilosEmpleadosNuevo.css">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap-theme.css">
    <script src="Bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="Bootstrap/js/bootstrap.min.js"></script>
    
</head>
<body>
    <div class="Boton-regresar">
            <a href="empleados.php" class="boton-regr"><button class="boton-regr">Regresar</button></a>
        </div>

<center><form action="registroEmpleados.php" method="POST">
        <h1 class="tituloForm">Registro de empleados</h1>
        <hr>
        <?php
            if(isset($_GET['error'])){
                ?>
                <p class="error">
                    <?php
                        echo $_GET['error']
                    ?>
                </p>
        <?php
                }
        ?>
        <hr>

        <label for="">Contraseña</label>
        <input type="password" nombre="password" placeholder="Contraseña" name="password" required minlength="8" maxlength="20">

        <label for="">Nombre</label>
        <input type="text" nombre="nombre" oninput="validarInput(event)"  placeholder="Nombre"  require name="nombre" >

        <label for="">Apellido Paterno</label>
        <input type="text" nombre="apellidoPaterno" oninput="validarInput(event)" placeholder="Apellido paterno" require name="apellidoPaterno" >

        <label for="">Apellido Materno</label>
        <input type="text" nombre="apellidoMaterno" oninput="validarInput(event)" placeholder="Apellido materno" require name="apellidoMaterno" >

        <label for="">Teléfono</label>
        <input type="tel" nombre="telefono" placeholder="Teléfono" name="telefono" oninput="validarNumeros(event)" required minlength="10" maxlength="10">

        <label for="opciones">Selecciona una opción:</label><br>
        <select name="opciones" id="opciones">
            <option value="Administrador">Administrador</option>
            <option value="Usuario">Usuario</option>
        </select>

        <hr>
        <center><button type="submit">Registrar</button></center>
  
    </form></center>


        <script>
            function validarInput(event) {
              const input = event.target;
              const inputValue = input.value;
            
              // Remover números y caracteres especiales del valor ingresado
              const soloLetras = inputValue.replace(/[^a-zA-Z]/g, '');
            
              // Actualizar el valor del input con solo letras
              input.value = soloLetras;
            }
        </script>
        
        <script>
            function validarNumeros(event) {
              const input = event.target;
              const inputValue = input.value;
            
              // Remover caracteres no numéricos del valor ingresado
              const soloNumeros = inputValue.replace(/\D/g, '');
            
              // Actualizar el valor del input con solo números
              input.value = soloNumeros;
            }
            </script>
</body>
</html>