<?php
	include("conexion.php");
	$idInquilinos = $_POST["idInquilinos"];
	$nuevoidInquilino = $_POST["idInquilinosEditar"];
	$piso= $_POST["piso"];
	$telefono = $_POST['telefono'];
    $cajonEstacionamiento = $_POST['cajonEstacionamiento'];
	$password = $_POST['password'];

	$actu2 = "UPDATE `inquilinos` SET `idInquilinos`='$nuevoidInquilino',`piso`='$piso', `telefono`='$telefono', `cajonEstacionamiento`='$cajonEstacionamiento'";
	
	if (!empty($password)) {
		$hash = password_hash($password, PASSWORD_DEFAULT);
		$actu2 .= ", `password`='$hash'";
	}

	$actu2 .= " WHERE idInquilinos='$idInquilinos'";

	$query = mysqli_query($conexion, $actu2);

	if ($query) {
        header("Location: usuarios.php");
	} else {
		echo "<script>alert('No se pudo actualizar este registro'); window.history.go(-1);</script>";
	}
?>