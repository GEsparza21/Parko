<?php

$host = "srv473.hstgr.io";
$user = "u263256283_admin";
$pass = "Parko3005";
$db = "u263256283_parkoapp";

$conexion = new mysqli($host, $user, $pass, $db);

if ($conexion->connect_errno) {
	echo "Lo sentimos, el sitio web está experimentando problemas";
} else {
	echo "Conexion exitosa";
}

?>