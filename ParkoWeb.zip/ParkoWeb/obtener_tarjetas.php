<?php
// Establecer la conexión a la base de datos
$servername = "srv473.hstgr.io";
$username = "u263256283_admin";
$password = "Parko3005";
$database = "u263256283_parkoapp";


$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
date_default_timezone_set('America/Mexico_City');
$fechaActual = date("Y-m-d");

// Realizar la consulta SQL para obtener los datos de la base de datos
$sql = "SELECT `evento`,`idInquilinos`, `fecha_hora`, `placa` FROM `registros` WHERE `fecha_hora`>= '$fechaActual 00:00:00' AND `fecha_hora` <= '$fechaActual 23:59:59'";
$result = $conn->query($sql);

// Verificar si se obtuvieron resultados
if ($result->num_rows > 0) {
    $tarjetas = array();

    // Recorrer los resultados y almacenarlos en un arreglo asociativo
    while ($row = $result->fetch_assoc()) {
        $tarjeta = array(
            "idInquilinos" => $row["idInquilinos"],
            "fecha_hora" => $row["fecha_hora"],
            "placa" => $row["placa"],
            "evento" => $row["evento"]
        );
        $tarjetas[] = $tarjeta;
    }

    // Devolver los datos en formato JSON
    echo json_encode($tarjetas);
} else {
    echo "No se encontraron resultados.";
}

// Cerrar la conexión
$conn->close();
?>