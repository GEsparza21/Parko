<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Datos</title>
    <link rel="shortcut icon" href="img/logo.jpg">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Bootstrap/css/bootstrap-theme.css">
    <script src="Bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="Bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/estilosEmpleadosNuevo.css">
</head>
<body>
    
<center>
    <form action="ActualizarInquilosBD.php" method="POST">
        <h1>Actualizar de los inquilinos</h1>
        <hr>

        <?php
        include("conexion.php");
        $id2 = $_GET["id"];

        $sql = "SELECT `idInquilinos`,`nombre`, `apellidoPaterno`, `apellidoMaterno`, `piso`, `noApartamento`, `telefono`, `cajonEstacionamiento` FROM `inquilinos` WHERE idInquilinos='$id2'";
        $resultado = mysqli_query($conexion, $sql);
        ?>

        <hr>
        <?php
        while ($filas = mysqli_fetch_assoc($resultado)) {
            ?>
            <label for="">Id de inquilino:</label>
            <input type="text" value="<?php echo $filas['idInquilinos'] ?>" name="idInquilinosEditar" id="idInquilinos" >
            
            <input type="hidden" value="<?php echo $filas['idInquilinos'] ?>" name="idInquilinos">
            
            <label for="">Nombre:</label>
            <input type="text" value="<?php echo $filas['nombre'] ?>" name="nombre" id="nombre" disabled>

            <label for="">Apellido Paterno:</label>
            <input type="text" value="<?php echo $filas['apellidoPaterno'] ?>" name="apellidoPaterno" id="apellidoPaterno" disabled>

            <label for="">Apellido materno:</label>
            <input type="text" value="<?php echo $filas['apellidoMaterno'] ?>" name="apellidoMaterno" id="apellidoMaterno" disabled>

            <label for="">No. placa:</label>
            <input type="text" value="<?php echo $filas['piso'] ?>" name="piso" id="piso" >

            <label for="">Número de apartamento:</label>
            <input type="text" value="<?php echo $filas['noApartamento'] ?>" name="noApartamento" id="noApartamento" disabled>

            <label for="">Teléfono:</label>
            <input type="tel" value="<?php echo $filas['telefono'] ?>" oninput="validarNumeros(event)" required minlength="10" id="telefono" maxlength="10" name="telefono">

            <label for="">Cajón de estacionamiento:</label>
            <input type="text" value="<?php echo $filas['cajonEstacionamiento'] ?>" oninput="validarNumeros(event)" name="cajonEstacionamiento" id="cajonEstacionamiento">

            <label for="">Contraseña:</label>
            <input type="password" placeholder="Actulizar contraseña" name="password" id="password">

            <hr>
            <?php } mysqli_free_result($resultado); ?>
            <center><button type="submit">Guardar</button></center>
    </form>
</center>

<script>
    function validarNumeros(event) {
      const input = event.target;
      const inputValue = input.value;
    
      // Remover caracteres no numéricos del valor ingresado
      const soloNumeros = inputValue.replace(/\D/g, '');
    
      // Actualizar el valor del input con solo números
      input.value = soloNumeros;
    }
</script>

</body>
</html>