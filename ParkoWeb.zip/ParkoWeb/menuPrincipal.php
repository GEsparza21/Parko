<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="shortcut icon" href="img/logo.jpg">

  <title>Cámaras</title>

  <link rel="stylesheet" href="css/estilosMenuPrincipal.css">

  <link rel="stylesheet" media="only screen and (max-width: 768px)" href="css/estilosMenuPrincipal.css">

</head>

<body>

  <!-- contenedor en el centro -->

  <h1>Videovigilancia</h1>

  <div id="main-container">

    <video id="video" autoplay></video>

  </div>

  <!-- fin contenedor -->

  <div id="second-container">
    <h2>Control de accesos</h2>
    <canvas id="canvas" style="display: none;"></canvas>
    <div id="console-output"></div>
    <video id="video" autoplay></video>
    <center><img id="last-photo" alt="Última foto tomada"></center>
    <div id="console-output"></div>
    <p id="qr-text">Lectura de QR: </p>
    <p id="qr-text2"></p>
    <p id="validation-message"></p>
  </div>










  <div id="sidemenu" class="menu-collapsed">

    <div id="header">

      <div id="title"><span>Menú Principal</span></div>

      <div id="menu-btn">

        <div class="btn-hamburger"></div>

        <div class="btn-hamburger"></div>

        <div class="btn-hamburger"></div>

      </div>

    </div>




    <div id="profile">

      <div id="photo"><img src="img/logo.jpg" alt="" style='width: 100%; height: auto; max-width: 100%' /></div>

      <div id="name"></div>

    </div>




    <div id="menu-items">

      <div class="item">

        <a href="menuPrincipal.php" style="background-color: #999697">

          <div class="icon"><img src="img/camara-de-seguridad.png" alt=""
              style='width: 100%; height: auto; max-width: 100%' /></div>

          <div class="title"><span>Cámaras</span></div>

        </a>

      </div>

      <div class="item">

        <a href="alertas.php">

          <div class="icon"><img src="img/logoalerta.png" alt="" style='width: 100%; height: auto; max-width: 100%' />
          </div>

          <div class="title"><span>Alertas</span></div>

        </a>

      </div>

      <div class="item">

        <a href="entradas.php">

          <div class="icon"><img src="img/logoentradas.png" alt="" style='width: 100%; height: auto; max-width: 100%' />
          </div>

          <div class="title"><span>Entradas</span></div>

        </a>

      </div>

      <div class="item">

        <a href="salidas.php">

          <div class="icon"><img src="img/logoSalidas.png" alt="" style='width: 100%; height: auto; max-width: 100%' />
          </div>

          <div class="title"><span>Salidas</span></div>

        </a>

      </div>

      <div class="item">

        <a href="usuarios.php">

          <div class="icon"><img src="img/logoperfilamarillo.png" alt=""
              style='width: 100%; height: auto; max-width: 100%' /></div>

          <div class="title"><span>Usuarios</span></div>

        </a>

      </div>

      <div class="item">

        <a href="empleados.php">

          <div class="icon"><img src="img/logoguardia.png" alt="" style='width: 100%; height: auto; max-width: 100%' />
          </div>

          <div class="title"><span>Empleados</span></div>

        </a>

      </div>
      <div class="item">
        <a href="entradasVisitantes.php">
          <div class="icon"><img src="img/codigo-qr.png" alt="" style='width: 100%; height: auto; max-width: 100%' />
          </div>
          <div class="title"><span>QR Visitantes</span></div>
        </a>
      </div>
      <div class="item">
        <a href="login.php">
          <div class="icon"><img src="img/cerrar-sesionPagina.png" alt=""
              style='width: 100%; height: auto; max-width: 100%' /></div>
          <div class="title"><span>Cerrar sesión</span></div>
        </a>
      </div>

    </div>

  </div>



  <! –– inicio video ––>





    <! –– final video ––>

      <script>

        const video = document.getElementById('video');

        const canvas = document.getElementById('canvas');

        const consoleOutput = document.getElementById('console-output');

        const lastPhoto = document.getElementById('last-photo');




        navigator.mediaDevices.getUserMedia({ video: true })

          .then(stream => {

            video.srcObject = stream;

            setInterval(takePhoto, 3000); // Tomar foto cada 3 segundos

          })

          .catch(error => {

            console.error('Error al acceder a la cámara:', error);

          });




        function takePhoto() {

          const context = canvas.getContext('2d');

          context.drawImage(video, 0, 0, canvas.width, canvas.height);

          canvas.toBlob(uploadPhoto, 'image/jpeg');

        }




        function uploadPhoto(blob) {

          const formData = new FormData();

          formData.append('upload', blob);

          formData.append('regions', 'us-ca'); // Opcional: Puedes cambiar esto según tus necesidades




          fetch('https://api.platerecognizer.com/v1/plate-reader/', {

            method: 'POST',

            headers: {

              'Authorization': 'Token 258a468de3e995dff1c39dbc456f3b0d65ff1adc'

            },

            body: formData

          })

            .then(response => response.json())

            .then(data => {

              console.log(data); // Mostrar información en la consola




              // Mostrar información estilizada en el elemento <div>

              const resultHTML = `

          <p><strong>Score:</strong> ${data.results[0].score}</p>

          <p><strong>Plate:</strong> ${data.results[0].plate}</p>

        `;

              consoleOutput.innerHTML = resultHTML;




              // Mostrar la última foto tomada solo si se detectó una placa

              if (data.results && data.results.length > 0) {

                const imageURL = URL.createObjectURL(blob);

                lastPhoto.src = imageURL;

              }

            })

            .catch(error => {

              console.error(error);

            });

        }

      </script>



      <script>

        const btn = document.querySelector('#menu-btn');

        const menu = document.querySelector('#sidemenu');

        btn.addEventListener('click', e => {

          menu.classList.toggle("menu-expanded");

          menu.classList.toggle("menu-collapsed");




          document.querySelector('body').classList.toggle('body-expanded');

        });

        'use strict';



      </script>



      <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>

      <script>

        // Acceder a la cámara web y mostrar la imagen en el elemento <video>

        navigator.mediaDevices.getUserMedia({ video: true })

          .then(function (stream) {

            var videoElement = document.getElementById('video');

            videoElement.srcObject = stream;




            // Configurar el lector de códigos QR

            var scanner = new Instascan.Scanner({ video: videoElement });

            scanner.addListener('scan', function (content) {

              var qrTextElement = document.getElementById('qr-text');

              qrTextElement.textContent = "Texto del QR: " + content;




              // Enviar el código QR al archivo PHP para verificar su validez

              var xhr = new XMLHttpRequest();

              var url = "verificar_qr.php";

              xhr.open("POST", url, true);

              xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

              xhr.onreadystatechange = function () {

                if (xhr.readyState === 4 && xhr.status === 200) {

                  var response = xhr.responseText;

                  var validationMessageElement = document.getElementById('validation-message');

                  validationMessageElement.textContent = response;

                }

              };

              xhr.send("qrCode=" + content);

            });




            // Iniciar la lectura de códigos QR

            Instascan.Camera.getCameras()

              .then(function (cameras) {

                if (cameras.length > 0) {

                  scanner.start(cameras[0]);

                } else {

                  console.error('No se encontraron cámaras en el dispositivo.');

                }

              })

              .catch(function (error) {

                console.error('Se produjo un error al acceder a las cámaras: ', error);

              });

          })

          .catch(function (error) {

            console.log("Se produjo un error al acceder a la cámara: " + error);

          });

      </script>






</body>

</html>