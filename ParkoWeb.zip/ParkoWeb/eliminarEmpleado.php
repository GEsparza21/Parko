<?php
        include("conexion.php");
        $id= $_GET['id'];
        $eliminar= "DELETE FROM `empleados` WHERE idUsuarios= '$id'";
        
        $resultadoEliminar= mysqli_query($conexion, $eliminar);

        if($resultadoEliminar){
            header("Location: empleados.php");
        }else{
            echo"<script>alert('No se pudo eliminar este registro'); window.history.go(-1);</script>";
        }

