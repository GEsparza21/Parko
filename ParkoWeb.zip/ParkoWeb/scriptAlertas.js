// Declarar una variable para almacenar las tarjetas
var tarjetas = [];

// Función para generar las tarjetas desde la base de datos
function generarTarjetas() {
    var container = document.getElementById("tarjetas-container");

    // Limpiar el contenedor
    container.innerHTML = "";

    // Generar las tarjetas dinámicamente
    tarjetas.forEach(function(tarjeta) {
        var card = document.createElement("div");
        card.className = "card";
        card.id = "tarjeta-" + tarjeta.id; // Asignar un ID a la tarjeta
        card.innerHTML = `
        <h3>Se detecto una ${tarjeta.evento} de inquilino con número de tarjeta  ${tarjeta.idInquilinos},</h3>
        <h3>placa: ${tarjeta.placa} entro el día y en la hora: ${tarjeta.fecha_hora}</h3>
        `;

        container.appendChild(card);
    });
}

/// Obtener los datos de la base de datos utilizando PHP y AJAX
function obtenerDatos() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            tarjetas = JSON.parse(this.responseText);
            generarTarjetas();
           
        }
        console.log(this.responseText);
    };
    xhttp.open("GET", "obtener_tarjetas.php", true);
    xhttp.send();
}
// Llamar a la función obtenerDatos() al cargar la página para obtener las tarjetas desde la base de datos
obtenerDatos();