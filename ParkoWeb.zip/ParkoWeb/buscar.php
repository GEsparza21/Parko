<?php
        include("conexion.php");

        $salida="";
        $query="SELECT * FROM `entradas` ORDER By `identradas`";

        if (isset($_POST['consulta'])) {
            $q=$mysqli-> real_escape_string($_POST['consulta']);
            $query="SELECT `idInquilinosEntradas`, `hora`, `fecha`, `placa` FROM `entradas` WHERE `fecha` LIKE '%" .$q. "%' OR `placa` LIKE '%" .$q. "%'";


        }
        $resultado= $mysqli->query($query);

        if ($resultado->num_rows > 0) {
            $salida.= "<table id="" class='tabla_datos' >
            <thead>
                <tr>
                    <th>No. Inquilino</th>
                    <th>No. Hora</th>
                    <th>No. Fecha</th>
                    <th>No. Placa</th>
                </tr>
            </thead>
            <tbody>";

                    while($filas=$resultado->fetch_assoc()){

               $salida.= "<tr>
                    <td> ".$filas['idInquilinosEntradas']." </td>
                    <td>   ".$filas['hora']."  </td>
                    <td>  ".$filas['fecha']."  </td>
                    <td> ".$filas['placa']." </td>
                </tr>";
             
                    }
                    $salida.="
            </tbody>
        </table>";
        }else {
            $salida.= "no hay datos";
        }

        echo $salida;
        $mysqli->close();
        ?>