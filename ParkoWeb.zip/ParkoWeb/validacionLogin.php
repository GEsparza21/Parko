<?php
session_start();
include('conexion.php');

if (isset($_POST['idUsuarios']) && isset($_POST['password'])) {
    function validate($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $idUsuarios = validate($_POST['idUsuarios']);
    $password = validate($_POST['password']);

    if (empty($idUsuarios)) {
        header("Location: login.php?error=Se debe de insertar el número del usuario");
        exit();
    } elseif (empty($password)) {
        header("Location: login.php?error=Se debe de insertar la contraseña");
        exit();
    } else {
        $query = "SELECT idUsuarios, password, opciones FROM empleados WHERE idUsuarios = ?";
        $statement = $conexion->prepare($query);
        $statement->bind_param("s", $idUsuarios);
        $statement->execute();
        $resultado = $statement->get_result();

        if ($resultado->num_rows === 1) {
            $fila = $resultado->fetch_assoc();

            if (password_verify($password, $fila['password'])) {
                $_SESSION['idUsuarios'] = $fila['idUsuarios'];
                $_SESSION['isAdmin'] = ($fila['opciones'] === 'Administrador');

                header("Location: menuPrincipal.php");
                exit();
            } else {
                header("Location: login.php?error=El número de usuario o la contraseña son incorrectas");
            }
        } else {
            header("Location: login.php?error=El número de usuario o la contraseña son incorrectas");
            exit();
        }
    }
} else {
    header("Location: login.php");
    exit();
}
?>