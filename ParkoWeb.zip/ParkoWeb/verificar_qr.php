<?php

// Establecer la conexión con la base de datos
$servername = "srv473.hstgr.io";
$username = "u263256283_admin";
$password = "Parko3005";
$dbname = "u263256283_parkoapp";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Configurar la zona horaria en GMT-6 (Ciudad de México)
date_default_timezone_set('America/Mexico_City');
$hora_actual = gmdate('Y-m-d H:i:s', time() - (6 * 3600));

// Obtener el código QR enviado por la página web
$qrCode = $_POST['qrCode'];

// Consultar la base de datos para verificar si el código QR está registrado
$sql = "SELECT * FROM visitantes WHERE codigo_acceso = '$qrCode'";
$result = $conn->query($sql);

// Verificar el resultado de la consulta
if ($result->num_rows > 0) {
    // El código QR está registrado y es válido
    echo "Usuario válido";

    // Obtener los datos del usuario placas
    $sql = "SELECT * FROM visitantes WHERE codigo_acceso = '$qrCode'";
    $resultado_autos = $conn->query($sql);
    if ($resultado_autos->num_rows > 0) {
        $fila_usuario = $resultado_autos->fetch_assoc();
        $placas_usuario = $fila_usuario['placas']; // Obtener placa
    } else {
        echo "Placa no encontrada.";
        $placas_usuario = "xxxxx";
    }


    // El qr es válido, verificar el último evento registrado en la tabla de registro
    $sql = "SELECT evento FROM registros WHERE idInquilinos = '$qrCode' ORDER BY fecha_hora DESC LIMIT 1";
    $resultado_registro = $conn->query($sql);

    if ($resultado_registro->num_rows > 0) {
        $fila_registro = $resultado_registro->fetch_assoc();
        $ultimoEvento = $fila_registro['evento'];

        if ($ultimoEvento == "Entrada") {
            // Insertar un nuevo registro de salida
            $sql = "INSERT INTO registros (idInquilinos, fecha_hora, placa, evento) VALUES ('$qrCode', '$hora_actual','$placas_usuario', 'Salida')";
            $conn->query($sql);
            echo "Se ha insertado un nuevo registro de Salida.";

            // Enviar instrucción al ESP32
            $esp32IP = "192.168.1.193"; // Reemplaza con la dirección IP del ESP32 en la red local
            $esp32Port = 80; // Reemplaza con el puerto en el que el ESP32 está escuchando las solicitudes
            $instruction = "Accion_Salida"; // Instrucción específica para un usuario válido
            $url = "http://" . $esp32IP . ":" . $esp32Port . "/enviar_instruccion?instruccion=" . urlencode($instruction);
            file_get_contents($url);

        } else {
            // Insertar un nuevo registro de entrada
            $sql = "INSERT INTO registros (idInquilinos, fecha_hora, placa, evento) VALUES ('$qrCode', '$hora_actual','$placas_usuario', 'Entrada')";
            $conn->query($sql);
            echo "Se ha insertado un nuevo registro de Entrada.";

            // Enviar instrucción al ESP32
            $esp32IP = "192.168.1.193"; // Reemplaza con la dirección IP del ESP32 en la red local
            $esp32Port = 80; // Reemplaza con el puerto en el que el ESP32 está escuchando las solicitudes
            $instruction = "Accion_Entrada"; // Instrucción específica para un usuario válido
            $url = "http://" . $esp32IP . ":" . $esp32Port . "/enviar_instruccion?instruccion=" . urlencode($instruction);
            file_get_contents($url);

        }
    } else {
        // No hay eventos registrados, insertar un nuevo registro de entrada
        $sql = "INSERT INTO registros (idInquilinos, fecha_hora, placa, evento) VALUES ('$qrCode', '$hora_actual','$placas_usuario', 'Entrada')";
        $conn->query($sql);
        echo "El usuario ha ingresado por primera vez.";

        // Enviar instrucción al ESP32
        $esp32IP = "192.168.1.193"; // Reemplaza con la dirección IP del ESP32 en la red local
        $esp32Port = 80; // Reemplaza con el puerto en el que el ESP32 está escuchando las solicitudes
        $instruction = "Accion_Entrada"; // Instrucción específica para un usuario válido
        $url = "http://" . $esp32IP . ":" . $esp32Port . "/enviar_instruccion?instruccion=" . urlencode($instruction);
        file_get_contents($url);

    }

} else {
    // El código QR no está registrado o no es válido
    echo "Usuario inválido";
    // Enviar instrucción al ESP32
    $esp32IP = "192.168.1.193"; // Reemplaza con la dirección IP del ESP32 en la red local
    $esp32Port = 80; // Reemplaza con el puerto en el que el ESP32 está escuchando las solicitudes
    $instruction = "Usuario_invalido"; // Instrucción específica para un usuario válido
    $url = "http://" . $esp32IP . ":" . $esp32Port . "/enviar_instruccion?instruccion=" . urlencode($instruction);
    file_get_contents($url);

}

$conn->close();
?>