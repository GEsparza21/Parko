<?php
include("conexion.php");
$password = $_POST['password'];
$nombre = $_POST['nombre'];
$apellidoPaterno = $_POST['apellidoPaterno'];
$apellidoMaterno = $_POST['apellidoMaterno'];
$telefono = $_POST['telefono'];
$opciones = $_POST['opciones'];

// Verificar si ya existe un registro con el mismo nombre, apellido paterno y apellido materno
$consultaExistencia = "SELECT COUNT(*) as total FROM empleados WHERE nombre = '$nombre' AND apellidoPaterno = '$apellidoPaterno' AND apellidoMaterno = '$apellidoMaterno'";
$resultadoExistencia = mysqli_query($conexion, $consultaExistencia);
$filaExistencia = mysqli_fetch_assoc($resultadoExistencia);
if ($filaExistencia['total'] > 0) {
    // Ya existe un registro con esos datos, redirigir con un mensaje de error
    header("Location: nuevoEmpleado.php?error=Ya existe un empleado con esa información");
    exit();
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$insertar = "INSERT INTO `empleados` (`password`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `telefono`, `opciones`) VALUES ('$hash', '$nombre', '$apellidoPaterno', '$apellidoMaterno', '$telefono', '$opciones')";
$query = mysqli_query($conexion, $insertar);
if ($query) {
    header("Location: empleados.php");
} else {
    header("Location: nuevoEmpleado.php?error=Revise los campos");
}
?>