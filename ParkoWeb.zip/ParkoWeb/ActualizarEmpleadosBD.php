<?php
	include("conexion.php");
    $idUsuarios= $_POST["idUsuarios"];
	$telefono=$_POST['telefono'];
	$password=$_POST['password'];

	$hash = password_hash($password, PASSWORD_DEFAULT);
	$actu="UPDATE `empleados` SET `telefono`='$telefono',`password`='$hash'  WHERE idUsuarios='$idUsuarios'";
	$query=mysqli_query($conexion,$actu);


	if ($query){
        header("Location: empleados.php");
	}else{
		echo"<script>alert('No se pudo actualizar este registro'); window.history.go(-1);</script>";
	}
	?>