<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logo.jpg">
    <title>Empleados</title>
    <link rel="stylesheet" href="css/estilosEmpleados.css">
    <link rel="stylesheet" href="css/estilosMenuPrincipal.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div id="sidemenu" class="menu-collapsed">
        <div id="header">
            <div id="title"><span>Menú Principal</span></div>
            <div id="menu-btn">
                <div class="btn-hamburger"></div>
                <div class="btn-hamburger"></div>
                <div class="btn-hamburger"></div>
            </div>
        </div>

        <div id="profile">
            <div id="photo"><img src="img/logo.jpg" alt="" style='width: 100%; height: auto; max-width: 100%' /></div>
            <div id="name"></div>
        </div>

        <div id="menu-items">
            <div class="item">
                <a href="menuPrincipal.php" target="_blank">
                    <div class="icon"><img src="img/camara-de-seguridad.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Cámaras</span></div>
                </a>
            </div>
            <div class="item">
                <a href="alertas.php">
                    <div class="icon"><img src="img/logoalerta.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Alertas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="entradas.php">
                    <div class="icon"><img src="img/logoentradas.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Entradas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="salidas.php">
                    <div class="icon"><img src="img/logoSalidas.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Salidas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="usuarios.php">
                    <div class="icon"><img src="img/logoperfilamarillo.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Usuarios</span></div>
                </a>
            </div>
            <div class="item">
                <a href="empleados.php" style="background-color: #999697">
                    <div class="icon"><img src="img/logoguardia.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Empleados</span></div>
                </a>
            </div>
            <div class="item">
                <a href="entradasVisitantes.php">
                    <div class="icon"><img src="img/codigo-qr.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>QR Visitantes</span></div>
                </a>
            </div>

            <div class="item">
                <a href="login.php">
                    <div class="icon"><img src="img/cerrar-sesionPagina.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Cerrar sesión</span></div>
                </a>
            </div>
        </div>
    </div>

    <! –– Inicio de formulario ––>


        <div class="container">
            <div class="table_header">
                <h2 style="text-align:center">Empleados</h2>
            </div>

            <div class="row">
                <a href="nuevoEmpleado.php"><button>Nuevo registro</button></a>
            </div>

            <br>
            <div class="container_table">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Apellido Paterno</th>
                            <th>Apellido Materno</th>
                            <th>Teléfono</th>
                            <th></th>
                            <th></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td> 17 </td>
                            <td> Janet </td>
                            <td> Garduo </td>
                            <td> Suarez </td>
                            <td> 5544615471 </td>
                            <td><a href="actualizarDatosEmpleados.php?id=17" onclick="obtenerDato(); return false;"
                                    class="table__item__link"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                        height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z" />
                                    </svg></a></td>
                            <td><a href="eliminarEmpleado.php?id=17" onclick="obtenerDato(); return false;"
                                    class="table__item__link"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                        height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z" />
                                    </svg></a></td>
                        </tr>
                        <tr>
                            <td> 18 </td>
                            <td> RicardoJoaquin </td>
                            <td> Llamas </td>
                            <td> Ortega </td>
                            <td> 5528289298 </td>
                            <td><a href="actualizarDatosEmpleados.php?id=18" onclick="obtenerDato(); return false;"
                                    class="table__item__link"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                        height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z" />
                                    </svg></a></td>
                            <td><a href="eliminarEmpleado.php?id=18" onclick="obtenerDato(); return false;"
                                    class="table__item__link"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                        height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z" />
                                    </svg></a></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>

        <! –– final de formulario ––>

            <script>
                const btn = document.querySelector('#menu-btn');
                const menu = document.querySelector('#sidemenu');
                btn.addEventListener('click', e => {
                    menu.classList.toggle("menu-expanded");
                    menu.classList.toggle("menu-collapsed");

                    document.querySelector('body').classList.toggle('body-expanded');
                });

            </script>

</body>

</html>