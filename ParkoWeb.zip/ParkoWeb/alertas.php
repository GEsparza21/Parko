<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logo.jpg">
    <link rel="stylesheet" href="css/stylesAlertas.css">
    <link rel="stylesheet" href="css/estilosMenuPrincipal.css">
    <title>Alertas</title>
</head>

<body>
    <div id="sidemenu" class="menu-collapsed">
        <div id="header">
            <div id="title"><span>Menú Principal</span></div>
            <div id="menu-btn">
                <div class="btn-hamburger"></div>
                <div class="btn-hamburger"></div>
                <div class="btn-hamburger"></div>
            </div>
        </div>

        <div id="profile">
            <div id="photo"><img src="img/logo.jpg" alt="" style='width: 100%; height: auto; max-width: 100%' /></div>
            <div id="name"></div>
        </div>

        <div id="menu-items">
            <div class="item">
                <a href="menuPrincipal.php" target="_blank">
                    <div class="icon"><img src="img/camara-de-seguridad.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Cámaras</span></div>
                </a>
            </div>
            <div class="item">
                <a href="alertas.php" style="background-color: #999697">
                    <div class="icon"><img src="img/logoalerta.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Alertas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="entradas.php">
                    <div class="icon"><img src="img/logoentradas.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Entradas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="salidas.php">
                    <div class="icon"><img src="img/logoSalidas.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Salidas</span></div>
                </a>
            </div>
            <div class="item">
                <a href="usuarios.php">
                    <div class="icon"><img src="img/logoperfilamarillo.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Usuarios</span></div>
                </a>
            </div>
            <div class="item">
                <a href="empleados.php">
                    <div class="icon"><img src="img/logoguardia.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Empleados</span></div>
                </a>
            </div>
            <div class="item">
                <a href="entradasVisitantes.php">
                    <div class="icon"><img src="img/codigo-qr.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>QR Visitantes</span></div>
                </a>
            </div>
            <div class="item">
                <a href="login.php">
                    <div class="icon"><img src="img/cerrar-sesionPagina.png" alt=""
                            style='width: 100%; height: auto; max-width: 100%' /></div>
                    <div class="title"><span>Cerrar sesión</span></div>
                </a>
            </div>
        </div>
    </div>

    <! –– Inicio Alertas ––>
        <div id="tarjetas-container"></div>

        <script src="scriptAlertas.js"></script>
        <! –– final Alertas ––>







            <script>
                const btn = document.querySelector('#menu-btn');
                const menu = document.querySelector('#sidemenu');
                btn.addEventListener('click', e => {
                    menu.classList.toggle("menu-expanded");
                    menu.classList.toggle("menu-collapsed");

                    document.querySelector('body').classList.toggle('body-expanded');
                });

            </script>
</body>

</html>